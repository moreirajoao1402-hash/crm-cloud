'use client';
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
export default function CRM() {
  const [clients, setClients] = useState([]);
  const [form, setForm] = useState({ nom:'', entreprise:'', email:'', telephone:'', notes:'' });
  async function chargerClients(){ const {data}=await supabase.from('clients').select('*').order('created_at',{ascending:false}); setClients(data); }
  async function ajouterClient(){ if(!form.nom.trim())return; await supabase.from('clients').insert(form); setForm({nom:'',entreprise:'',email:'',telephone:'',notes:''}); chargerClients(); }
  useEffect(()=>{ chargerClients(); },[]);
  return (<div>CRM Cloud</div>);
}